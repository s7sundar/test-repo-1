@extends('layouts.template') 
@section('menu_link','opportunity-leads')
@section('menu', 'Opportunity/Leads')
@section('submenu','Opportunity/Leads') 
@section('content')


<form method="post" action="/leads/save" name="leads" id="leads">

	<div class="row">
		<div class="form-group col-md-6">
			<label for="organization_name">Customer Name</label> <input
				type="text" class="form-control" id="organization_name"
				name="organization_name" placeholder="Enter Customer Name">
		</div>
		<div class="col-md-6">
			<label for="lead_type">Customer Type</label><br/>
			<div class="form-check form-check-inline">
			  <label class="form-check-label">
			    <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio1" value="option1"> Opportunity
			  </label>
			</div>
			<div class="form-check form-check-inline">
			  <label class="form-check-label">
			    <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio2" value="option2"> Leads
			  </label>
			</div>
			<div class="form-check form-check-inline disabled">
			  <label class="form-check-label">
			    <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio3" value="option3"> Customer
			  </label>
			</div>
		</div>
		
		<div class="form-group col-md-6">
			<label for="organization_name">Department Name</label> <input
				type="text" class="form-control" id="organization_name"
				name="organization_name" placeholder="Enter Department Name">
		</div>
		
		<div class="form-group col-md-6">
			<label for="organization_name">Project Name / Quote Title</label> <input
				type="text" class="form-control" id="organization_name"
				name="organization_name" placeholder="Enter Project Name / Quote Title">
		</div>
		
		<div class="form-group col-md-6">
			<label for="organization_name">Sales Person</label> <input
				type="text" class="form-control" id="organization_name"
				name="organization_name" placeholder="Enter Sales Person">
		</div>
		
		<div class="form-group col-md-6">
			<label for="organization_name">Decision maker</label> <input
				type="text" class="form-control" id="organization_name"
				name="organization_name" placeholder="Enter Decision maker">
		</div>
		
		<div class="form-group col-md-6">
			<label for="organization_name">Turnover approx</label> <input
				type="text" class="form-control" id="organization_name"
				name="organization_name" placeholder="Enter Turnover approx">
		</div>
		
		<div class="form-group col-md-6">
			<label for="organization_name">Business Domain</label> <input
				type="text" class="form-control" id="organization_name"
				name="organization_name" placeholder="Enter Business Domain">
		</div>
		
		<div class="form-group col-md-6">
			<label for="organization_name">Decision maker Email</label> <input
				type="text" class="form-control" id="organization_name"
				name="organization_name" placeholder="Enter Decision maker Email">
		</div>
		
		<div class="form-group col-md-6">
			<label for="organization_name">Decision maker Contact number</label> <input
				type="text" class="form-control" id="organization_name"
				name="organization_name" placeholder="Enter Decision maker Email">
		</div>
		
		<div class="col-md-6">
			&nbsp;
		</div>
		
		<div class="col-md-6 text-center">
			<button class="btn btn-primary" type="button" name="saveandnext" id="saveandnext">Save &amp; Next &gt;</button>
			<!-- <button class="btn btn-default" type="button" name="saveandnext" id="saveandnext">Add Address</button> -->
		</div>
	</div>
	
	<div class="row">
		
	</div>
	

</form>
@endsection
